const mongoose = require("mongoose");

const personagemSchema = new mongoose.Schema({
    nome: { type: String, required: true },
    descricao: { type: String, required: true },
    img: { type: String, required: true }  // Atualiza o campo para a URL da imagem
});

module.exports = mongoose.model("Personagem", personagemSchema);
